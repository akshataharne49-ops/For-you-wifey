const pages = document.querySelectorAll('.page');
const music = document.getElementById("bgMusic");
let musicStarted = false; 

// 1. Sabse pehle pages ko sahi order (z-index) mein lagao
pages.forEach((page, index) => {
    page.style.zIndex = pages.length - index;
});

// 2. Click karne par kya hoga?
pages.forEach((page, index) => {
    page.onclick = function() {
        
        // --- AUTO MUSIC LOGIC ---
        if (!musicStarted) {
            music.currentTime = 6; // 30th second se shuru hoga
            music.play().catch(e => console.log("Click again to play"));
            musicStarted = true;
        }

        // --- PAGE FLIP LOGIC ---
        if (this.classList.contains('flipped')) {
            // Wapas piche palatna
            this.classList.remove('flipped');
            setTimeout(() => {
                this.style.zIndex = pages.length - index;
            }, 500);
        } else {
            // Aage palatna
            this.classList.add('flipped');
            // Palatne ke baad ise niche bhej do
            setTimeout(() => {
                this.style.zIndex = index;
            }, 500);
        }
    }
});

// Extra button ke liye (safe side)
function playMusic() {
    if (music.paused) { music.play(); } else { music.pause(); }
}